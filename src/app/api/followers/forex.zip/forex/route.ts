import { NextRequest, NextResponse } from 'next/server';
import {
  getForexRate,
  getForexTimeSeries,
  getAllForexRates,
  MAJOR_FOREX_PAIRS,
} from '@/lib/forex-service';


/**
 * GET /api/forex
 * Get all major forex rates or specific pair
 * Query params: pair (optional, e.g., EURUSD)
 */
export async function GET(request: NextRequest) {
  const pair = request.nextUrl.searchParams.get('pair');

  try {
    if (pair) {
      // Get specific pair
      if (pair.length !== 6) {
        return NextResponse.json(
          { success: false, error: 'Invalid pair format. Use XXXYYYZZZ format' },
          { status: 400 }
        );
      }

      const from = pair.substring(0, 3).toUpperCase();
      const to = pair.substring(3, 6).toUpperCase();

      const rate = await getForexRate(from, to);
      if (!rate) {
        return NextResponse.json(
          { success: false, error: 'Failed to fetch rate' },
          { status: 500 }
        );
      }

      return NextResponse.json({
        success: true,
        rate,
        serverTime: new Date().toISOString(),
      });
    }

    // Get all major pairs
    const rates = await getAllForexRates();
    return NextResponse.json({
      success: true,
      count: rates.length,
      rates,
      pairs: MAJOR_FOREX_PAIRS,
      serverTime: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Forex API error:', error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

/**
 * GET /api/forex/chart
 * Get time series data for charting
 * Query params: pair (required), interval (intraday|daily, default: intraday)
 */
export async function getForexChart(request: NextRequest) {
  const pair = request.nextUrl.searchParams.get('pair');
  const interval = (request.nextUrl.searchParams.get('interval') ||
    'intraday') as 'intraday' | 'daily';

  if (!pair || pair.length !== 6) {
    return NextResponse.json(
      { success: false, error: 'Missing or invalid pair parameter' },
      { status: 400 }
    );
  }

  try {
    const timeSeries = await getForexTimeSeries(pair.toUpperCase(), interval);
    if (!timeSeries) {
      return NextResponse.json(
        { success: false, error: 'Failed to fetch chart data' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      timeSeries,
      serverTime: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Forex chart API error:', error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

